package com.company;

public class Atk implements Comparable<Atk>{
    String kdBarang;
    String jenisBarang;
    String namaBarang;
    int stok;

    public Atk(String kdBarang, String jenisBarang, String namaBarang, int stok){
        if(!(kdBarang.split("")[0].equals("A") || kdBarang.split("")[0].equals("B"))){
            throw new IllegalArgumentException("Kode Barang yang dimasukan harus A atau B");
        }
        this.kdBarang = kdBarang;
        this.jenisBarang = jenisBarang;
        this.namaBarang = namaBarang;
        this.stok = stok;
    }

    public String getKdBarang() {
        return kdBarang;
    }

    @Override
    public String toString() {
        return kdBarang + " " + jenisBarang + " " + namaBarang + " " + stok + " | ";
    }

    @Override
    public int compareTo(Atk o) {
        return this.getKdBarang().compareTo(o.getKdBarang());
    }
}
