package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        GenArrayList<Atk> atkList = new GenArrayList<>(3);
        GenArrayList<Bag> bagList = new GenArrayList<>(1);

//        --------------------------------------------- ini untuk Atk -------------------------------------------
        for(int i=0; i<5; i++){
            String kdBarang = input.next();
            String jenisBarang = input.next();
            String namaBarang = input.next();
            int stok = input.nextInt();
            atkList.addData(new Atk(kdBarang,jenisBarang, namaBarang, stok));
        }

        Atk atkAdd = new Atk("A001", "tas", "pensil hitam", 12);
        atkList.addData(atkAdd);
        atkList.displaySort();
        System.out.println("dibawah ini adalah data yang sudah di edit");
        Atk atkEdit = new Atk("A002", "tas edit", "pensil putih edit", 23);
        atkList.editData(atkAdd, atkEdit);
        atkList.display();
        System.out.println("dibawah ini adalah data yang sudah di remove");
        atkList.removeData(atkEdit);
        atkList.display();


        System.out.println();
//        ------------------------------------------------- Ini Untuk Bag ---------------------------------------------
        for(int i=0; i<5; i++){
            String kdBarang = input.next();
            String jenisBarang = input.next();
            String namaBarang = input.next();
            int stok = input.nextInt();
            bagList.addData(new Bag(kdBarang,jenisBarang, namaBarang, stok));
        }

        Bag bagAdd = new Bag("C001", "tas", "tas hitam", 12);
        bagList.addData(bagAdd);
        bagList.displaySort();
        Bag bagEdit = new Bag("C001", "tas edit", "tas hitam edit", 23);
        bagList.editData(bagAdd, bagEdit);
        System.out.println("dibawah ini data yang sudah di edit");
        bagList.display();
        bagList.removeData(bagEdit);
        System.out.println("dibawah ini data yang sudah di remove");
        bagList.display();

    }
}