package com.company;

public class Bag implements Comparable<Bag>{
    String kdBarang;
    String jenisBarang;
    String namaBarang;
    int stok;

    public Bag(String kdBarang, String jenisBarang, String namaBarang, int stok){
        if(!(kdBarang.split("")[0].equals("C"))){
            throw new IllegalArgumentException("Kode Barang yang dimasukan harus C");
        }
        this.kdBarang = kdBarang;
        this.jenisBarang = jenisBarang;
        this.namaBarang = namaBarang;
        this.stok = stok;
    }

    public String getKdBarang() {
        return kdBarang;
    }

    @Override
    public String toString() {
        return kdBarang + " " + jenisBarang + " " + namaBarang + " " + stok + " | ";
    }

    @Override
    public int compareTo(Bag o) {
        return this.getKdBarang().compareTo(o.getKdBarang());
    }
}
